#!/bin/bash
cd "$(dirname "$0")"
npm install
echo "========================================="
echo "KEEP THIS WINDOW OPEN"
echo "This handles the receipt printer cutting commands."
echo "========================================="
node server.js
