const express = require('express');
const cors = require('cors');
const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const os = require('os');

const app = express();
app.use(cors());
app.use(express.json());

const PORT = 7878;

app.post('/print', (req, res) => {
  try {
    const { copies } = req.body;
    if (!copies || !Array.isArray(copies)) {
      return res.status(400).json({ error: 'Invalid payload: expected copies array' });
    }

    console.log(`Received print job with ${copies.length} copies.`);

    const isWin = os.platform() === 'win32';

    copies.forEach((copy, idx) => {
      console.log(`Printing copy: ${copy.type}`);
      const content = copy.content;
      
      const feedCmd = '\n\n\n\n\n\n'; 
      const cutCmd = Buffer.from([0x1D, 0x56, 0x00]); // GS V 0 (Standard ESC/POS Cut)
      
      const rawContent = Buffer.from(content + feedCmd, 'utf8');
      const payload = Buffer.concat([rawContent, cutCmd]);

      const tempFile = path.join(os.tmpdir(), `receipt_copy_${idx}.bin`);
      fs.writeFileSync(tempFile, payload);

      if (isWin) {
         // Windows Flawless Raw Spooler Bypass!
         // This C# wrapper allows Powershell to invoke the Windows winspool.drv safely to pass RAW bytes perfectly without scaling!
         const psScript = `
$code = @"
using System;
using System.Runtime.InteropServices;
public class RawPrint {
    [DllImport("winspool.Drv", EntryPoint = "OpenPrinterA", SetLastError = true, CharSet = CharSet.Ansi, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
    public static extern bool OpenPrinter([MarshalAs(UnmanagedType.LPStr)] string szPrinter, out IntPtr hPrinter, IntPtr pd);
    [DllImport("winspool.Drv", EntryPoint = "ClosePrinter", SetLastError = true, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
    public static extern bool ClosePrinter(IntPtr hPrinter);
    [DllImport("winspool.Drv", EntryPoint = "StartDocPrinterA", SetLastError = true, CharSet = CharSet.Ansi, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
    public static extern bool StartDocPrinter(IntPtr hPrinter, Int32 level, [In, MarshalAs(UnmanagedType.LPStruct)] DOCINFOA di);
    [DllImport("winspool.Drv", EntryPoint = "EndDocPrinter", SetLastError = true, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
    public static extern bool EndDocPrinter(IntPtr hPrinter);
    [DllImport("winspool.Drv", EntryPoint = "StartPagePrinter", SetLastError = true, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
    public static extern bool StartPagePrinter(IntPtr hPrinter);
    [DllImport("winspool.Drv", EntryPoint = "EndPagePrinter", SetLastError = true, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
    public static extern bool EndPagePrinter(IntPtr hPrinter);
    [DllImport("winspool.Drv", EntryPoint = "WritePrinter", SetLastError = true, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
    public static extern bool WritePrinter(IntPtr hPrinter, IntPtr pBytes, Int32 dwCount, out Int32 dwWritten);
    
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    public class DOCINFOA {
        [MarshalAs(UnmanagedType.LPStr)] public string pDocName;
        [MarshalAs(UnmanagedType.LPStr)] public string pOutputFile;
        [MarshalAs(UnmanagedType.LPStr)] public string pDatatype;
    }
    
    public static bool SendBytesToPrinter(string szPrinterName, byte[] data) {
        IntPtr pUnmanagedBytes = Marshal.AllocCoTaskMem(data.Length);
        Marshal.Copy(data, 0, pUnmanagedBytes, data.Length);
        bool bSuccess = false;
        IntPtr hPrinter = new IntPtr(0);
        DOCINFOA di = new DOCINFOA();
        di.pDocName = "Thermal Receipt Job";
        di.pDatatype = "RAW";
        if (OpenPrinter(szPrinterName.Normalize(), out hPrinter, IntPtr.Zero)) {
            if (StartDocPrinter(hPrinter, 1, di)) {
                if (StartPagePrinter(hPrinter)) {
                    Int32 dwWritten = 0;
                    bSuccess = WritePrinter(hPrinter, pUnmanagedBytes, data.Length, out dwWritten);
                    EndPagePrinter(hPrinter);
                }
                EndDocPrinter(hPrinter);
            }
            ClosePrinter(hPrinter);
        }
        Marshal.FreeCoTaskMem(pUnmanagedBytes);
        return bSuccess;
    }
}
"@
Add-Type -TypeDefinition $code
$printerName = (Get-WmiObject -Class Win32_Printer -Filter "Default=True").Name
$bytes = [System.IO.File]::ReadAllBytes('${tempFile.replace(/\\/g, '\\\\')}')
[RawPrint]::SendBytesToPrinter($printerName, $bytes)
`;
         const psFile = path.join(os.tmpdir(), `print_script_${idx}.ps1`);
         fs.writeFileSync(psFile, psScript, 'utf8');

         try {
            console.log(`Spooling job ${idx + 1} exactly bypassing Windows GDI natively...`);
            const out = execSync(`powershell -ExecutionPolicy Bypass -File "${psFile}"`);
            console.log("Powershell Success:", out.toString());
         } catch(e) {
            console.error("Windows Print failed:", e.message);
         }

         try {
           fs.unlinkSync(tempFile);
           fs.unlinkSync(psFile);
         } catch(e) {}

      } else {
         // Mac/Linux: lp -o raw natively
         try {
            execSync(`lp -o raw "${tempFile}"`);
         } catch(e) {
            console.error("Mac/Linux generic print error:", e.message);
         }
         
         try {
           fs.unlinkSync(tempFile);
         } catch(e) {}
      }
    });

    res.json({ success: true, message: 'Print jobs dispatched locally' });

  } catch (error) {
    console.error('Print Bridge Error:', error);
    res.status(500).json({ error: error.message });
  }
});

app.listen(PORT, () => {
  console.log(`=========================================`);
  console.log(`CAFE POS LOCAL PRINT BRIDGE ACTIVE `);
  console.log(`Listening on http://localhost:${PORT}`);
  console.log(`Leave this terminal running in the background.`);
  console.log(`=========================================`);
});
