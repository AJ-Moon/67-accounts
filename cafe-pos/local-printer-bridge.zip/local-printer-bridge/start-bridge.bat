@echo off
title Cafe POS - Print Bridge
echo Starting Cafe POS Local Print Bridge...
cd %~dp0
call npm install
echo =========================================
echo KEEP THIS WINDOW OPEN
echo This handles the receipt printer cutting commands.
echo =========================================
node server.js
pause
